Scripts which are only optional, ie not required for Prefab pipeline.
Some are sub-parts of other scripts/functions, and are included here to allow for more fine-grained analysis.
Others are simple helpers, moving and or renaming files as intermediate solutions used during dev. 