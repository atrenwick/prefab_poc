# ANR Prefab Gitlab

Notes/warnings:
1. Be particularly careful with scripts ; most are able to be run as-is, where-is when opened in an IDE.
2. Not all scripts have been taken to the completion necessary for CLI running.

